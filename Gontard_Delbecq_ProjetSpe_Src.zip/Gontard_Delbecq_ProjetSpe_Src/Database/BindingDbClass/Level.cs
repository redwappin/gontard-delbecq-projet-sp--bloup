﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level
{
    public int Number { get; set; }
    public  int TrapsCount  { get; set; }
    public int BonusCount { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
    
    public String BossName { get; set; }

    public Coordinate MaxJumpDistance;

}
