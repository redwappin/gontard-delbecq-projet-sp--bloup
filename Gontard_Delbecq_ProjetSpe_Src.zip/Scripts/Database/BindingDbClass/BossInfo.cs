﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossInfo : CharacterInfo
{
    public float MaxStamina;
}
