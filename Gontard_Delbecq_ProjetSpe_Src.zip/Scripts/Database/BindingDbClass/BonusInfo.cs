﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BonusInfo
{
    public int Id { get; set; }

    public string Name { get; set; }
    public int Multipler { get; set; }

    public string Improved_Features {get; set;}
}
