﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterInfo
{
    public float Attack_Multiplier;
    public string Name;
    public int MaxLife;
    public float Speed;
    public float JumpHeight;
}
